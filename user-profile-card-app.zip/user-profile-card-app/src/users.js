export const users = [
    { id: 1, name: "Alice", role: "Frontend Developer", location: "Delhi" },
    { id: 2, name: "Bob", role: "Backend Developer", location: "Mumbai" },
    { id: 3, name: "Carol", role: "Full Stack Developer", location: "Remote" }
    
  ];
  
